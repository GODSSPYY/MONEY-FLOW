import React, { createContext, useContext, useState } from 'react';
import { toast } from '@/components/ui/use-toast';

interface Transaction {
  id: string;
  type: 'sent' | 'received';
  amount: number;
  recipient?: string;
  sender?: string;
  date: string;
  status: 'completed' | 'pending' | 'failed';
}

interface AppContextType {
  balance: number;
  transactions: Transaction[];
  sendMoney: (recipient: string, amount: number) => Promise<void>;
  requestMoney: (amount: number) => Promise<string>;
  addTransaction: (transaction: Omit<Transaction, 'id' | 'date'>) => void;
}

const defaultAppContext: AppContextType = {
  balance: 2450.75,
  transactions: [],
  sendMoney: async () => {},
  requestMoney: async () => '',
  addTransaction: () => {},
};

const AppContext = createContext<AppContextType>(defaultAppContext);

export const useAppContext = () => useContext(AppContext);

export const AppProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [balance, setBalance] = useState(2450.75);
  const [transactions, setTransactions] = useState<Transaction[]>([
    {
      id: '1',
      type: 'received',
      amount: 250,
      sender: 'john@email.com',
      date: '2024-01-15',
      status: 'completed'
    },
    {
      id: '2',
      type: 'sent',
      amount: 100,
      recipient: '+1234567890',
      date: '2024-01-14',
      status: 'completed'
    },
    {
      id: '3',
      type: 'received',
      amount: 75,
      sender: 'sarah@email.com',
      date: '2024-01-13',
      status: 'completed'
    }
  ]);

  const sendMoney = async (recipient: string, amount: number) => {
    if (amount > balance) {
      throw new Error('Insufficient funds');
    }

    const transaction: Transaction = {
      id: Date.now().toString(),
      type: 'sent',
      amount,
      recipient,
      date: new Date().toISOString().split('T')[0],
      status: 'pending'
    };

    setTransactions(prev => [transaction, ...prev]);
    
    // Simulate processing delay
    await new Promise(resolve => setTimeout(resolve, 1500));
    
    setBalance(prev => prev - amount);
    setTransactions(prev => 
      prev.map(t => t.id === transaction.id ? { ...t, status: 'completed' } : t)
    );
  };

  const requestMoney = async (amount: number) => {
    // Generate payment link
    const paymentId = Math.random().toString(36).substr(2, 9);
    const link = `https://payflow.app/pay/${paymentId}?amount=${amount}`;
    
    await new Promise(resolve => setTimeout(resolve, 1000));
    return link;
  };

  const addTransaction = (transactionData: Omit<Transaction, 'id' | 'date'>) => {
    const transaction: Transaction = {
      ...transactionData,
      id: Date.now().toString(),
      date: new Date().toISOString().split('T')[0]
    };
    
    setTransactions(prev => [transaction, ...prev]);
    
    if (transaction.type === 'received') {
      setBalance(prev => prev + transaction.amount);
    }
  };

  return (
    <AppContext.Provider
      value={{
        balance,
        transactions,
        sendMoney,
        requestMoney,
        addTransaction
      }}
    >
      {children}
    </AppContext.Provider>
  );
};
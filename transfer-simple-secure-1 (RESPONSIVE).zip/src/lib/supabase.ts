import { createClient } from '@supabase/supabase-js';


// Initialize Supabase client
// Using direct values from project configuration
const supabaseUrl = 'https://eptlehsotmzvueudatvd.supabase.co';
const supabaseKey = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImVwdGxlaHNvdG16dnVldWRhdHZkIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NTE2MDA2ODcsImV4cCI6MjA2NzE3NjY4N30.OcgEU-UOus-Ir-Nd3MG2rvyzYbJt55uDoip8etOIKdo';
const supabase = createClient(supabaseUrl, supabaseKey);


export { supabase };
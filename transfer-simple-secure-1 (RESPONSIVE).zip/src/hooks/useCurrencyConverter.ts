import { useState, useEffect } from 'react';

export const useCurrencyConverter = () => {
  const [fromCurrency, setFromCurrency] = useState('NGN');
  const [toCurrency, setToCurrency] = useState('USD');
  const [amount, setAmount] = useState(0);
  const [exchangeRate, setExchangeRate] = useState(1);
  const [convertedAmount, setConvertedAmount] = useState(0);
  const [loading, setLoading] = useState(false);

  const fetchExchangeRate = async (from: string, to: string) => {
    setLoading(true);
    try {
      const response = await fetch(
        'https://eptlehsotmzvueudatvd.supabase.co/functions/v1/40eacb34-bd2c-471a-ac0b-147a9613c323',
        {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
          },
          body: JSON.stringify({
            fromCurrency: from,
            toCurrency: to
          })
        }
      );
      
      const data = await response.json();
      const rate = data.exchangeRate || 1;
      setExchangeRate(rate);
      return rate;
    } catch (error) {
      console.error('Failed to fetch exchange rate:', error);
      // Fallback to mock rates
      const mockRates: Record<string, Record<string, number>> = {
        NGN: { USD: 0.0012, EUR: 0.0011, GBP: 0.00095, NGN: 1 },
        USD: { NGN: 830, EUR: 0.92, GBP: 0.79, USD: 1 }
      };
      const rate = mockRates[from]?.[to] || 1;
      setExchangeRate(rate);
      return rate;
    } finally {
      setLoading(false);
    }
  };

  const convertCurrency = (amount: number, rate: number) => {
    return amount * rate;
  };

  useEffect(() => {
    if (fromCurrency && toCurrency) {
      fetchExchangeRate(fromCurrency, toCurrency);
    }
  }, [fromCurrency, toCurrency]);

  useEffect(() => {
    const converted = convertCurrency(amount, exchangeRate);
    setConvertedAmount(converted);
  }, [amount, exchangeRate]);

  return {
    fromCurrency,
    toCurrency,
    amount,
    exchangeRate,
    convertedAmount,
    loading,
    setFromCurrency,
    setToCurrency,
    setAmount,
    convertCurrency,
    fetchExchangeRate
  };
};
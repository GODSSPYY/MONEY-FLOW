import { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { ArrowUpDown } from 'lucide-react';
import { Button } from '@/components/ui/button';

interface CurrencyConverterProps {
  fromCurrency: string;
  toCurrency: string;
  amount: number;
  onAmountChange: (amount: number) => void;
  onFromCurrencyChange: (currency: string) => void;
  onToCurrencyChange: (currency: string) => void;
  convertedAmount: number;
  exchangeRate: number;
}

const currencies = [
  { code: 'NGN', name: 'Nigerian Naira', symbol: '₦' },
  { code: 'USD', name: 'US Dollar', symbol: '$' },
  { code: 'EUR', name: 'Euro', symbol: '€' },
  { code: 'GBP', name: 'British Pound', symbol: '£' },
  { code: 'CAD', name: 'Canadian Dollar', symbol: 'C$' },
  { code: 'AUD', name: 'Australian Dollar', symbol: 'A$' },
  { code: 'JPY', name: 'Japanese Yen', symbol: '¥' },
  { code: 'CHF', name: 'Swiss Franc', symbol: 'CHF' },
  { code: 'CNY', name: 'Chinese Yuan', symbol: '¥' },
  { code: 'ZAR', name: 'South African Rand', symbol: 'R' }
];

const CurrencyConverter = ({
  fromCurrency,
  toCurrency,
  amount,
  onAmountChange,
  onFromCurrencyChange,
  onToCurrencyChange,
  convertedAmount,
  exchangeRate
}: CurrencyConverterProps) => {
  const [localAmount, setLocalAmount] = useState(amount.toString());

  useEffect(() => {
    setLocalAmount(amount.toString());
  }, [amount]);

  const handleAmountChange = (value: string) => {
    setLocalAmount(value);
    const numValue = parseFloat(value) || 0;
    onAmountChange(numValue);
  };

  const swapCurrencies = () => {
    onFromCurrencyChange(toCurrency);
    onToCurrencyChange(fromCurrency);
  };

  const fromCurrencySymbol = currencies.find(c => c.code === fromCurrency)?.symbol || '';
  const toCurrencySymbol = currencies.find(c => c.code === toCurrency)?.symbol || '';

  return (
    <Card className="w-full border-finance-green/20">
      <CardHeader className="pb-3 sm:pb-4">
        <CardTitle className="text-finance-navy text-center text-base sm:text-lg">Currency Converter</CardTitle>
      </CardHeader>
      <CardContent className="space-y-3 sm:space-y-4 p-4 sm:p-6">
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 sm:gap-4">
          <div className="space-y-2">
            <Label className="text-finance-navy font-medium text-sm sm:text-base">From</Label>
            <Select value={fromCurrency} onValueChange={onFromCurrencyChange}>
              <SelectTrigger className="border-finance-green/30 h-10 sm:h-11 text-sm sm:text-base">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                {currencies.map((currency) => (
                  <SelectItem key={currency.code} value={currency.code} className="text-sm sm:text-base">
                    <span className="hidden sm:inline">{currency.symbol} {currency.code}</span>
                    <span className="sm:hidden">{currency.code}</span>
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
          <div className="space-y-2">
            <Label className="text-finance-navy font-medium text-sm sm:text-base">To</Label>
            <Select value={toCurrency} onValueChange={onToCurrencyChange}>
              <SelectTrigger className="border-finance-green/30 h-10 sm:h-11 text-sm sm:text-base">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                {currencies.map((currency) => (
                  <SelectItem key={currency.code} value={currency.code} className="text-sm sm:text-base">
                    <span className="hidden sm:inline">{currency.symbol} {currency.code}</span>
                    <span className="sm:hidden">{currency.code}</span>
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
        </div>
        
        <div className="flex justify-center">
          <Button
            variant="outline"
            size="sm"
            onClick={swapCurrencies}
            className="border-finance-green/30 hover:bg-finance-green-light h-8 w-8 sm:h-10 sm:w-10 p-0"
          >
            <ArrowUpDown className="w-3 h-3 sm:w-4 sm:h-4" />
          </Button>
        </div>
        
        <div className="space-y-2">
          <Label className="text-finance-navy font-medium text-sm sm:text-base">Amount</Label>
          <Input
            type="number"
            value={localAmount}
            onChange={(e) => handleAmountChange(e.target.value)}
            placeholder="0.00"
            className="border-finance-green/30 focus:border-finance-green h-10 sm:h-11 text-sm sm:text-base"
          />
        </div>
        
        <div className="bg-finance-green-light/30 p-3 sm:p-4 rounded-lg">
          <div className="text-center">
            <div className="text-lg sm:text-xl lg:text-2xl font-bold text-finance-navy break-all">
              {fromCurrencySymbol}{amount.toFixed(2)} = {toCurrencySymbol}{convertedAmount.toFixed(2)}
            </div>
            <div className="text-xs sm:text-sm text-finance-navy/70 mt-1 break-words">
              Rate: 1 {fromCurrency} = {exchangeRate.toFixed(4)} {toCurrency}
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  );
};

export default CurrencyConverter;
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Wallet, TrendingUp, ArrowUpRight, ArrowDownLeft, Send, Download, Banknote } from 'lucide-react';
import { useAppContext } from '@/contexts/AppContext';

const Dashboard = () => {
  const { balance, transactions } = useAppContext();

  const monthlyIncrease = 12.5; // Mock data

  return (
    <div className="space-y-4 sm:space-y-6">
      {/* Balance Card */}
      <Card className="bg-gradient-to-r from-finance-green to-finance-navy text-white border-0 shadow-lg">
        <CardHeader className="pb-3 sm:pb-4">
          <CardTitle className="flex items-center gap-2 text-base sm:text-lg">
            <Wallet className="w-4 h-4 sm:w-5 sm:h-5 flex-shrink-0" />
            <span className="truncate">Available Balance</span>
          </CardTitle>
        </CardHeader>
        <CardContent className="pt-0">
          <div className="text-2xl sm:text-3xl lg:text-4xl font-bold break-all">₦{balance.toFixed(2)}</div>
          <div className="flex items-center gap-1 mt-2 text-green-100">
            <TrendingUp className="w-3 h-3 sm:w-4 sm:h-4 flex-shrink-0" />
            <span className="text-xs sm:text-sm">+{monthlyIncrease}% this month</span>
          </div>
        </CardContent>
      </Card>

      {/* Recent Transactions */}
      <Card className="border-finance-green/20">
        <CardHeader className="pb-3 sm:pb-4">
          <CardTitle className="text-finance-navy text-base sm:text-lg">Recent Transactions</CardTitle>
        </CardHeader>
        <CardContent className="pt-0">
          <div className="space-y-2 sm:space-y-3">
            {transactions.length === 0 ? (
              <div className="text-center text-muted-foreground py-6 sm:py-8 text-sm sm:text-base">
                No transactions yet. Start sending, receiving, or withdrawing money!
              </div>
            ) : (
              transactions.slice(0, 5).map((tx) => (
                <div key={tx.id} className="flex items-center justify-between p-2 sm:p-3 border border-finance-green/10 rounded-lg hover:bg-finance-green-light/50 transition-colors">
                  <div className="flex items-center gap-2 sm:gap-3 min-w-0 flex-1">
                    <div className={`p-1.5 sm:p-2 rounded-full flex-shrink-0 ${
                      tx.type === 'received' ? 'bg-success/10' : 'bg-destructive/10'
                    }`}>
                      {tx.type === 'received' ? 
                        <ArrowDownLeft className="w-3 h-3 sm:w-4 sm:h-4 text-success" /> :
                        <ArrowUpRight className="w-3 h-3 sm:w-4 sm:h-4 text-destructive" />
                      }
                    </div>
                    <div className="min-w-0 flex-1">
                      <div className="font-medium text-finance-navy text-sm sm:text-base truncate">
                        {tx.type === 'received' ? 'from' : 'to'} {tx.sender || tx.recipient}
                      </div>
                      <div className="text-xs sm:text-sm text-muted-foreground">{tx.date}</div>
                    </div>
                  </div>
                  <div className="text-right flex-shrink-0 ml-2">
                    <div className={`font-semibold text-sm sm:text-base ${
                      tx.type === 'received' ? 'text-success' : 'text-destructive'
                    }`}>
                      {tx.type === 'received' ? '+' : '-'}₦{tx.amount}
                    </div>
                    <Badge variant={tx.status === 'completed' ? 'default' : 'secondary'} className="bg-finance-green text-white text-xs">
                      {tx.status}
                    </Badge>
                  </div>
                </div>
              ))
            )}
          </div>
        </CardContent>
      </Card>

      {/* Quick Actions */}
      <Card className="border-finance-green/20">
        <CardHeader className="pb-3 sm:pb-4">
          <CardTitle className="text-finance-navy text-base sm:text-lg">Quick Actions</CardTitle>
        </CardHeader>
        <CardContent className="pt-0">
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3 sm:gap-4">
            <div className="p-3 sm:p-4 border border-finance-green/20 rounded-lg text-center hover:bg-finance-green-light/50 cursor-pointer transition-all hover:border-finance-green/40 hover:shadow-md">
              <div className="mb-2 sm:mb-3">
                <Send className="w-6 h-6 sm:w-8 sm:h-8 text-finance-green mx-auto" />
              </div>
              <div className="font-medium text-finance-navy text-sm sm:text-base">Send Money</div>
              <div className="text-xs sm:text-sm text-muted-foreground">Transfer to friends</div>
            </div>
            <div className="p-3 sm:p-4 border border-finance-green/20 rounded-lg text-center hover:bg-finance-green-light/50 cursor-pointer transition-all hover:border-finance-green/40 hover:shadow-md">
              <div className="mb-2 sm:mb-3">
                <Download className="w-6 h-6 sm:w-8 sm:h-8 text-finance-green mx-auto" />
              </div>
              <div className="font-medium text-finance-navy text-sm sm:text-base">Receive Money</div>
              <div className="text-xs sm:text-sm text-muted-foreground">Get paid easily</div>
            </div>
            <div className="p-3 sm:p-4 border border-finance-green/20 rounded-lg text-center hover:bg-finance-green-light/50 cursor-pointer transition-all hover:border-finance-green/40 hover:shadow-md sm:col-span-2 lg:col-span-1">
              <div className="mb-2 sm:mb-3">
                <Banknote className="w-6 h-6 sm:w-8 sm:h-8 text-finance-green mx-auto" />
              </div>
              <div className="font-medium text-finance-navy text-sm sm:text-base">Withdraw</div>
              <div className="text-xs sm:text-sm text-muted-foreground">To Nigerian banks</div>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default Dashboard;
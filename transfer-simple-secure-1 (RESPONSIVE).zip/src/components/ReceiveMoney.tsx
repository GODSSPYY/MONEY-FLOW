import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { toast } from '@/components/ui/use-toast';
import { Download, Copy } from 'lucide-react';
import { useAppContext } from '@/contexts/AppContext';
import CurrencyConverter from './CurrencyConverter';
import { useCurrencyConverter } from '@/hooks/useCurrencyConverter';

const ReceiveMoney = () => {
  const [paymentLink, setPaymentLink] = useState('');
  const [loading, setLoading] = useState(false);
  const { requestMoney } = useAppContext();
  const {
    fromCurrency,
    toCurrency,
    amount,
    exchangeRate,
    convertedAmount,
    setFromCurrency,
    setToCurrency,
    setAmount
  } = useCurrencyConverter();

  const userEmail = 'user@nairaflow.app';
  const userPhone = '+234 (0) 123-456-7890';
  const finalAmount = fromCurrency === 'NGN' ? amount : convertedAmount;

  const generatePaymentLink = async () => {
    if (!amount || amount <= 0) {
      toast({ title: 'Error', description: 'Please enter a valid amount', variant: 'destructive' });
      return;
    }

    setLoading(true);
    try {
      const link = await requestMoney(finalAmount);
      setPaymentLink(link);
      const displayAmount = fromCurrency === 'NGN' ? 
        `₦${amount.toFixed(2)}` : 
        `${fromCurrency === 'USD' ? '$' : ''}${amount.toFixed(2)} ${fromCurrency} (₦${finalAmount.toFixed(2)})`;
      toast({ title: 'Success!', description: `Payment link generated for ${displayAmount}` });
    } catch (error) {
      toast({ 
        title: 'Error', 
        description: 'Failed to generate payment link', 
        variant: 'destructive' 
      });
    } finally {
      setLoading(false);
    }
  };

  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text);
    toast({ title: 'Copied!', description: 'Copied to clipboard' });
  };

  return (
    <div className="space-y-4 sm:space-y-6">
      <div className="w-full">
        <CurrencyConverter
          fromCurrency={fromCurrency}
          toCurrency={toCurrency}
          amount={amount}
          onAmountChange={setAmount}
          onFromCurrencyChange={setFromCurrency}
          onToCurrencyChange={setToCurrency}
          convertedAmount={convertedAmount}
          exchangeRate={exchangeRate}
        />
      </div>
      
      <Card className="w-full max-w-md mx-auto border-finance-green/20 shadow-lg">
        <CardHeader className="text-center bg-finance-green-light/50 pb-3 sm:pb-4">
          <CardTitle className="flex items-center justify-center gap-2 text-finance-navy text-base sm:text-lg">
            <Download className="w-4 h-4 sm:w-5 sm:h-5 text-finance-green flex-shrink-0" />
            Request Money
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4 p-4 sm:p-6">
          {fromCurrency !== 'NGN' && (
            <div className="text-center text-xs sm:text-sm text-finance-navy/70 bg-finance-green-light/30 p-3 rounded-lg">
              <div className="break-words">
                Requesting: ₦{finalAmount.toFixed(2)} (from {fromCurrency === 'USD' ? '$' : ''}{amount.toFixed(2)} {fromCurrency})
              </div>
            </div>
          )}
          
          <Button 
            onClick={generatePaymentLink} 
            disabled={loading || !amount || amount <= 0}
            className="w-full bg-finance-green hover:bg-finance-green/90 text-white font-medium py-3 sm:py-4 shadow-md hover:shadow-lg transition-all text-sm sm:text-base h-10 sm:h-12"
          >
            {loading ? 'Generating...' : 'Generate Payment Link'}
          </Button>

          <div className="space-y-3 p-3 sm:p-4 bg-finance-green-light/30 rounded-lg">
            <div className="text-xs sm:text-sm font-medium text-center text-finance-navy">Share your payment info:</div>
            <div className="space-y-2">
              <div className="flex items-center justify-between p-2 bg-white rounded border border-finance-green/20 gap-2">
                <span className="text-xs sm:text-sm truncate flex-1 text-finance-navy">{userEmail}</span>
                <Button size="sm" variant="ghost" onClick={() => copyToClipboard(userEmail)} className="hover:bg-finance-green-light p-1 h-8 w-8 flex-shrink-0">
                  <Copy className="w-3 h-3 sm:w-4 sm:h-4 text-finance-green" />
                </Button>
              </div>
              <div className="flex items-center justify-between p-2 bg-white rounded border border-finance-green/20 gap-2">
                <span className="text-xs sm:text-sm text-finance-navy">{userPhone}</span>
                <Button size="sm" variant="ghost" onClick={() => copyToClipboard(userPhone)} className="hover:bg-finance-green-light p-1 h-8 w-8 flex-shrink-0">
                  <Copy className="w-3 h-3 sm:w-4 sm:h-4 text-finance-green" />
                </Button>
              </div>
            </div>
          </div>

          {paymentLink && (
            <div className="space-y-2 p-3 sm:p-4 bg-finance-green-light/50 rounded-lg border border-finance-green/30">
              <div className="text-xs sm:text-sm font-medium text-finance-navy">Payment Link Generated:</div>
              <div className="flex items-center justify-between p-2 bg-white rounded border border-finance-green/20 gap-2">
                <span className="text-xs sm:text-sm truncate flex-1 text-finance-green">{paymentLink}</span>
                <Button size="sm" variant="ghost" onClick={() => copyToClipboard(paymentLink)} className="hover:bg-finance-green-light p-1 h-8 w-8 flex-shrink-0">
                  <Copy className="w-3 h-3 sm:w-4 sm:h-4 text-finance-green" />
                </Button>
              </div>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
};

export default ReceiveMoney;
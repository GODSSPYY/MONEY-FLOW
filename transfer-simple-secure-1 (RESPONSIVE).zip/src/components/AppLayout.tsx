import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Home, Send, Download, Menu, X, Banknote } from 'lucide-react';
import Dashboard from './Dashboard';
import SendMoney from './SendMoney';
import ReceiveMoney from './ReceiveMoney';
import WithdrawMoney from './WithdrawMoney';

const AppLayout = () => {
  const [activeTab, setActiveTab] = useState('dashboard');
  const [sidebarOpen, setSidebarOpen] = useState(false);

  const navigation = [
    { id: 'dashboard', label: 'Dashboard', icon: Home },
    { id: 'send', label: 'Send Money', icon: Send },
    { id: 'receive', label: 'Receive Money', icon: Download },
    { id: 'withdraw', label: 'Withdraw', icon: Banknote },
  ];

  const renderContent = () => {
    switch (activeTab) {
      case 'dashboard':
        return <Dashboard />;
      case 'send':
        return <SendMoney />;
      case 'receive':
        return <ReceiveMoney />;
      case 'withdraw':
        return <WithdrawMoney />;
      default:
        return <Dashboard />;
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-finance-green-light to-finance-navy-light">
      {/* Header */}
      <header className="bg-white shadow-sm border-b border-finance-green/20 sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-2 sm:px-4 lg:px-6">
          <div className="flex justify-between items-center h-14 sm:h-16">
            <div className="flex items-center">
              <Button
                variant="ghost"
                size="sm"
                onClick={() => setSidebarOpen(!sidebarOpen)}
                className="lg:hidden hover:bg-finance-green-light p-2"
              >
                {sidebarOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
              </Button>
              <h1 className="text-lg sm:text-xl lg:text-2xl font-bold bg-gradient-to-r from-finance-green to-finance-navy bg-clip-text text-transparent ml-2">
                Naira Flow
              </h1>
            </div>
            <div className="hidden sm:flex items-center space-x-4">
              <div className="text-xs sm:text-sm text-finance-navy/70">Welcome back!</div>
            </div>
          </div>
        </div>
      </header>

      <div className="max-w-7xl mx-auto px-2 sm:px-4 lg:px-6 py-4 sm:py-6 lg:py-8">
        <div className="flex flex-col lg:flex-row gap-4 sm:gap-6 lg:gap-8">
          {/* Sidebar */}
          <div className={`lg:w-64 xl:w-72 ${sidebarOpen ? 'block' : 'hidden lg:block'} ${sidebarOpen ? 'fixed inset-0 z-40 bg-black/50' : ''}`}>
            <div className={`${sidebarOpen ? 'fixed left-0 top-0 h-full w-64 bg-white shadow-lg z-50 pt-16' : ''}`}>
              <Card className="border-finance-green/20 bg-white/90 backdrop-blur-sm h-full">
                <CardContent className="p-3 sm:p-4">
                  <nav className="space-y-1 sm:space-y-2">
                    {navigation.map((item) => {
                      const Icon = item.icon;
                      return (
                        <Button
                          key={item.id}
                          variant={activeTab === item.id ? 'default' : 'ghost'}
                          className={`w-full justify-start transition-all text-sm sm:text-base py-2 sm:py-3 ${
                            activeTab === item.id 
                              ? 'bg-finance-green text-white hover:bg-finance-green/90 shadow-md' 
                              : 'hover:bg-finance-green-light text-finance-navy hover:text-finance-navy'
                          }`}
                          onClick={() => {
                            setActiveTab(item.id);
                            setSidebarOpen(false);
                          }}
                        >
                          <Icon className="w-4 h-4 mr-2 flex-shrink-0" />
                          <span className="truncate">{item.label}</span>
                        </Button>
                      );
                    })}
                  </nav>
                </CardContent>
              </Card>
            </div>
          </div>

          {/* Main Content */}
          <div className="flex-1 min-w-0">
            <div className="bg-white/90 backdrop-blur-sm rounded-lg border border-finance-green/20 p-3 sm:p-4 lg:p-6">
              {renderContent()}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default AppLayout;
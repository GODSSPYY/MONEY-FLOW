import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { toast } from '@/components/ui/use-toast';
import { Send, Mail, Phone } from 'lucide-react';
import { useAppContext } from '@/contexts/AppContext';
import CurrencyConverter from './CurrencyConverter';
import { useCurrencyConverter } from '@/hooks/useCurrencyConverter';

const SendMoney = () => {
  const [recipient, setRecipient] = useState('');
  const [loading, setLoading] = useState(false);
  const { sendMoney, balance } = useAppContext();
  const {
    fromCurrency,
    toCurrency,
    amount,
    exchangeRate,
    convertedAmount,
    setFromCurrency,
    setToCurrency,
    setAmount
  } = useCurrencyConverter();

  const isEmail = recipient.includes('@');
  const isPhone = /^[\d\s\-\+\(\)]+$/.test(recipient);
  const finalAmount = fromCurrency === 'NGN' ? amount : convertedAmount;

  const handleSend = async () => {
    if (!recipient || !amount) {
      toast({ title: 'Error', description: 'Please fill all fields', variant: 'destructive' });
      return;
    }

    if (amount <= 0) {
      toast({ title: 'Error', description: 'Amount must be greater than 0', variant: 'destructive' });
      return;
    }

    if (finalAmount > balance) {
      toast({ title: 'Error', description: 'Insufficient funds', variant: 'destructive' });
      return;
    }

    setLoading(true);
    try {
      await sendMoney(recipient, finalAmount);
      const displayAmount = fromCurrency === 'NGN' ? 
        `₦${amount.toFixed(2)}` : 
        `${fromCurrency === 'USD' ? '$' : ''}${amount.toFixed(2)} ${fromCurrency} (₦${finalAmount.toFixed(2)})`;
      toast({ title: 'Success!', description: `${displayAmount} sent to ${recipient}` });
      setRecipient('');
      setAmount(0);
    } catch (error) {
      toast({ 
        title: 'Error', 
        description: error instanceof Error ? error.message : 'Failed to send money', 
        variant: 'destructive' 
      });
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="space-y-4 sm:space-y-6">
      <div className="w-full">
        <CurrencyConverter
          fromCurrency={fromCurrency}
          toCurrency={toCurrency}
          amount={amount}
          onAmountChange={setAmount}
          onFromCurrencyChange={setFromCurrency}
          onToCurrencyChange={setToCurrency}
          convertedAmount={convertedAmount}
          exchangeRate={exchangeRate}
        />
      </div>
      
      <Card className="w-full max-w-md mx-auto border-finance-green/20 shadow-lg">
        <CardHeader className="text-center bg-finance-green-light/50 pb-3 sm:pb-4">
          <CardTitle className="flex items-center justify-center gap-2 text-finance-navy text-base sm:text-lg">
            <Send className="w-4 h-4 sm:w-5 sm:h-5 text-finance-green flex-shrink-0" />
            Send Money
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4 p-4 sm:p-6">
          <div className="text-center text-xs sm:text-sm text-finance-navy/70 bg-finance-green-light/30 p-3 rounded-lg">
            <div>Available Balance: <span className="font-semibold text-finance-green">₦{balance.toFixed(2)}</span></div>
            {fromCurrency !== 'NGN' && (
              <div className="text-xs mt-1 break-words">
                Sending: ₦{finalAmount.toFixed(2)} (from {fromCurrency === 'USD' ? '$' : ''}{amount.toFixed(2)} {fromCurrency})
              </div>
            )}
          </div>
          
          <div className="space-y-2">
            <Label htmlFor="recipient" className="text-finance-navy font-medium text-sm sm:text-base">Recipient</Label>
            <div className="relative">
              <Input
                id="recipient"
                placeholder="Email or phone number"
                value={recipient}
                onChange={(e) => setRecipient(e.target.value)}
                className="pl-10 border-finance-green/30 focus:border-finance-green focus:ring-finance-green/20 text-sm sm:text-base h-10 sm:h-11"
              />
              <div className="absolute left-3 top-1/2 transform -translate-y-1/2">
                {isEmail ? <Mail className="w-4 h-4 text-finance-green" /> : 
                 isPhone ? <Phone className="w-4 h-4 text-finance-green" /> : 
                 <div className="w-4 h-4" />}
              </div>
            </div>
          </div>
          
          <Button 
            onClick={handleSend} 
            disabled={loading || !recipient || !amount || amount <= 0 || finalAmount > balance}
            className="w-full bg-finance-green hover:bg-finance-green/90 text-white font-medium py-3 sm:py-4 shadow-md hover:shadow-lg transition-all text-sm sm:text-base h-10 sm:h-12"
          >
            {loading ? 'Sending...' : 'Send Money'}
          </Button>
        </CardContent>
      </Card>
    </div>
  );
};

export default SendMoney;
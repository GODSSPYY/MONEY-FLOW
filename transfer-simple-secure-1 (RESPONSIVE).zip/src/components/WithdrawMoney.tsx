import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { toast } from '@/components/ui/use-toast';
import { Banknote } from 'lucide-react';
import { useAppContext } from '@/contexts/AppContext';

const WithdrawMoney = () => {
  const [amount, setAmount] = useState('');
  const [bankName, setBankName] = useState('');
  const [accountNumber, setAccountNumber] = useState('');
  const [accountName, setAccountName] = useState('');
  const [loading, setLoading] = useState(false);
  const { withdrawMoney, balance } = useAppContext();

  const nigerianBanks = [
    'Access Bank', 'Zenith Bank', 'GTBank', 'First Bank', 'UBA',
    'Fidelity Bank', 'Union Bank', 'Sterling Bank', 'Stanbic IBTC',
    'Wema Bank', 'Polaris Bank', 'Keystone Bank', 'FCMB'
  ];

  const handleWithdraw = async () => {
    const withdrawAmount = parseFloat(amount);
    
    if (!amount || !bankName || !accountNumber || !accountName) {
      toast({ title: 'Error', description: 'Please fill all fields', variant: 'destructive' });
      return;
    }

    if (withdrawAmount <= 0) {
      toast({ title: 'Error', description: 'Amount must be greater than 0', variant: 'destructive' });
      return;
    }

    if (withdrawAmount > balance) {
      toast({ title: 'Error', description: 'Insufficient funds', variant: 'destructive' });
      return;
    }

    setLoading(true);
    try {
      await withdrawMoney(withdrawAmount, bankName, accountNumber, accountName);
      toast({ title: 'Success!', description: `₦${withdrawAmount.toFixed(2)} withdrawal initiated to ${bankName}` });
      setAmount('');
      setBankName('');
      setAccountNumber('');
      setAccountName('');
    } catch (error) {
      toast({ 
        title: 'Error', 
        description: 'Failed to process withdrawal', 
        variant: 'destructive' 
      });
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="space-y-4 sm:space-y-6">
      <Card className="w-full max-w-md mx-auto border-finance-green/20 shadow-lg">
        <CardHeader className="text-center bg-finance-green-light/50 pb-3 sm:pb-4">
          <CardTitle className="flex items-center justify-center gap-2 text-finance-navy text-base sm:text-lg">
            <Banknote className="w-4 h-4 sm:w-5 sm:h-5 text-finance-green flex-shrink-0" />
            Withdraw Money
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4 p-4 sm:p-6">
          <div className="text-center text-xs sm:text-sm text-finance-navy/70 bg-finance-green-light/30 p-3 rounded-lg">
            Available Balance: <span className="font-semibold text-finance-green">₦{balance.toFixed(2)}</span>
          </div>
          
          <div className="space-y-2">
            <Label htmlFor="amount" className="text-finance-navy font-medium text-sm sm:text-base">Amount (₦)</Label>
            <Input
              id="amount"
              type="number"
              placeholder="0.00"
              value={amount}
              onChange={(e) => setAmount(e.target.value)}
              className="border-finance-green/30 focus:border-finance-green focus:ring-finance-green/20 text-sm sm:text-base h-10 sm:h-11"
            />
          </div>
          
          <div className="space-y-2">
            <Label htmlFor="bank" className="text-finance-navy font-medium text-sm sm:text-base">Bank</Label>
            <Select value={bankName} onValueChange={setBankName}>
              <SelectTrigger className="border-finance-green/30 h-10 sm:h-11 text-sm sm:text-base">
                <SelectValue placeholder="Select bank" />
              </SelectTrigger>
              <SelectContent>
                {nigerianBanks.map((bank) => (
                  <SelectItem key={bank} value={bank} className="text-sm sm:text-base">
                    {bank}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
          
          <div className="space-y-2">
            <Label htmlFor="accountNumber" className="text-finance-navy font-medium text-sm sm:text-base">Account Number</Label>
            <Input
              id="accountNumber"
              placeholder="1234567890"
              value={accountNumber}
              onChange={(e) => setAccountNumber(e.target.value)}
              className="border-finance-green/30 focus:border-finance-green focus:ring-finance-green/20 text-sm sm:text-base h-10 sm:h-11"
            />
          </div>
          
          <div className="space-y-2">
            <Label htmlFor="accountName" className="text-finance-navy font-medium text-sm sm:text-base">Account Name</Label>
            <Input
              id="accountName"
              placeholder="John Doe"
              value={accountName}
              onChange={(e) => setAccountName(e.target.value)}
              className="border-finance-green/30 focus:border-finance-green focus:ring-finance-green/20 text-sm sm:text-base h-10 sm:h-11"
            />
          </div>
          
          <Button 
            onClick={handleWithdraw} 
            disabled={loading || !amount || !bankName || !accountNumber || !accountName || parseFloat(amount) <= 0 || parseFloat(amount) > balance}
            className="w-full bg-finance-green hover:bg-finance-green/90 text-white font-medium py-3 sm:py-4 shadow-md hover:shadow-lg transition-all text-sm sm:text-base h-10 sm:h-12"
          >
            {loading ? 'Processing...' : 'Withdraw Money'}
          </Button>
        </CardContent>
      </Card>
    </div>
  );
};

export default WithdrawMoney;
# Naira Flow - Mobile Money Transfer App

A modern React finance application for sending and receiving money using mobile numbers or email addresses.

## Features

- **Dashboard**: View account balance and transaction history
- **Send Money**: Transfer funds using mobile number or email
- **Receive Money**: Generate payment links and share contact details
- **Dark Theme**: Modern dark UI with gradient accents
- **Responsive Design**: Works seamlessly on desktop and mobile

## Tech Stack

- React 18 with TypeScript
- Vite for fast development
- Tailwind CSS for styling
- Shadcn/ui components
- Lucide React icons
- React Hook Form for form handling

## Getting Started

1. Install dependencies:
```bash
npm install
```

2. Start the development server:
```bash
npm run dev
```

3. Build for production:
```bash
npm run build
```

## Usage

- Navigate between Dashboard, Send Money, and Receive Money sections
- Send money by entering recipient's email or phone number
- Receive money by sharing your payment link or contact details
- View all transactions in the dashboard

## License

MIT License